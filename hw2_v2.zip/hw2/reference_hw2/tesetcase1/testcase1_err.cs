/*There should be at least one function definition in the program*/
int a;
int b;
