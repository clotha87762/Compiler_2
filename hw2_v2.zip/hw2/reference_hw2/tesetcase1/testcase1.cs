
int a;
int b;

int main()
{
   int i;
   int j;
   int k;

   a = a + b + 3 + 6;
   a = i + j + k + 3;
   a = a / 2;
   return 0;
}

